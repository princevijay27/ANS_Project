import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/pages/Home";
import Header from "./components/pages/Header";
import { ThemeProvider } from "@mui/material";
import { Web3ReactProvider, useWeb3React } from "@web3-react/core";
import { Web3Provider } from "@ethersproject/providers";
import CreatePool from "./components/pages/CreatePool";
import UserRoutes from "./components/pages/UserRoute";
import Protected from "./components/pages/Protected";
import { OWNER_ADDRESS } from "./components/pages/address";
import { useEffect, useState } from "react";
import WrongChain from "./components/pages/walletConnect/WrongChian";
import MetamaskProvider from "./components/pages/walletConnect/WalletProvider";
import NotFound from "./components/pages/NotFound";
import theme from "./Theme";

export function getLibrary(provider) {
  let chainType;
  if (provider.chainId === "number") {
    chainType = provider.chainId;
  } else if (provider.chainId === "string") {
    chainType = parseInt(provider.chainId);
  } else {
    chainType = "any";
  }
  const library = new Web3Provider(provider, chainType);
  library.pollingInterval = 15_000;
  return library;
}

function App() {
  const { account, chainId, library } = useWeb3React();
  const [isOwner, setIsOwner] = useState(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (account && account === OWNER_ADDRESS) {
      setIsOwner(false);
    } else {
      setIsOwner(true);
    }
    if (account && chainId !== 56) {
      setOpen(true);
    }
  }, [account, chainId]);

  return (
    <>
      <Web3ReactProvider getLibrary={getLibrary}>
        <MetamaskProvider>
          <ThemeProvider theme={theme}>
            <WrongChain
              open={open}
              library={library}
              chainId={chainId}
              account={account}
            />
            <BrowserRouter>
              <Header />
              {/* <NewHeader /> */}
              <Routes>
                <Route exact path="/" element={<Home />} />
                <Route
                  exact
                  path="/createPool"
                  element={
                    <Protected isOwner={isOwner}>
                      <CreatePool />
                    </Protected>
                  }
                />
                <Route exact path="/user" element={<UserRoutes />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </ThemeProvider>
        </MetamaskProvider>
      </Web3ReactProvider>
    </>
  );
}

export default App;
