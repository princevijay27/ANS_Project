import { createTheme, responsiveFontSizes } from "@mui/material/styles";

const font = "'Oswald', sans-serif";

let theme = createTheme({
  palette: {
    primary: { main: "#000" },
    secondary: { main: "#FC841A" },
    error: { main: "#6E353A" },
    warning: { main: "#F5EE9E" },
    info: { main: "#7A3FB5" },
    success: { main: "#110D2E" },
    background: { default: "#FDFFFC" },
  },
  breakpoints: {
    values: { xs: 600, sm: 800, md: 1000, lg: 1200, xl: 1536 },
  },
  typography: {
    fontFamily: font,
    h5: { fontSize: 36, latterSpacing: "0.03rem", fontWeight: "700" },
    h6: {
      fontSize: 20,
      latterSpacing: "0.03rem",
      fontWeight: "500",
      padding: "10px",
    },
    h4: { fontSize: 20, latterSpacing: "0.03rem", fontWeight: "500" },
    h3: { fontSize: 20, latterSpacing: "0.03rem", fontWeight: "600" },
    h2: {
      // color: '#ED64A6',
      color: "linear-gradient(to right, #f0346e , #fc6650)",
    },
    subtitle1: {
      fontSize: 16,
      fontWeight: "400",
      padding: "2px 0",
      letterSpacing: "0.03rem",
    },
    subtitle2: { fontSize: 12, letterSpacing: "0.03rem", fontWeight: "400" },
    body1: { fontSize: 14, letterSpacing: "0.03rem" },
    body2: { fontSize: 16, letterSpacing: "0.03rem" },
  },
});

theme = responsiveFontSizes(theme);

export default theme;
