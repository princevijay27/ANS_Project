import {
  Container,
  Grid,
  Box,
  Button,
  Typography,
  Card,
  Dialog,
} from "@mui/material";
import React, { useState, useEffect } from "react";
import { NFT_FACTORY, OWNER_ADDRESS } from "./address";
import { useStyles } from "./css/CreatePoolCss";
import { useWeb3React } from "@web3-react/core";
import { Formik } from "formik";
import * as Yup from "yup";
import Web3 from "web3";
import ConnectWallet from "./walletConnect/ConnectWallet";
import nftFactory from "../../ABI/nftFactory.json";
import Loader from "./walletConnect/Loader";
import { useNavigate } from "react-router-dom";

const validations = Yup.object({
  ownerAddress: Yup.string(),
  tokenAddress: Yup.string().required("Pool token address is required."),
  rewardAmount: Yup.number()
    .typeError("Reward should be a number.")
    .min(0)
    .moreThan(0, "You must enter valid number.")
    .required("Reward is required."),
  decimalValue: Yup.number()
    .typeError("Decimal should be a number.")
    .min(0)
    .moreThan(0, "You must enter valid number.")
    .required("Decimal is required."),
  rewardDuration: Yup.number()
    .typeError("Duration should be a number.")
    .min(0)
    .moreThan(0, "You must enter valid number.")
    .required("Duration is required."),
  totalTokenStake: Yup.number()
    .typeError("stake should be a number.")
    .min(0)
    .moreThan(0, "You must enter valid number.")
    .required("Stake amount is required."),
});

const CreatePool = () => {
  const { classes } = useStyles();
  const { account, library } = useWeb3React();
  const lib = library;
  const web3 = new Web3(lib?.provider);
  const navigate = useNavigate();

  const [tsxState, setTsxState] = useState(false);
  const [openWallets, setOpenWallets] = useState(false);
  const [user, setUser] = useState("");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (account) {
      if (account === OWNER_ADDRESS) {
        setOpenWallets(false);
        setUser(account);
      } else {
        navigate(-1);
      }
    }
  }, [account]); // eslint-disable-line react-hooks/exhaustive-deps

  const btnhandler = () => {
    setOpenWallets(true);
  };

  const handleClose = () => {
    setOpenWallets(false);
  };

  const handleClosePopUp = () => {
    setOpen(false);
  };

  const createPool = async (value, resetForm) => {
    if (user) {
      setTsxState(true);
      let userAccount = account;
      let instance = new web3.eth.Contract(nftFactory, NFT_FACTORY);
      await instance.methods
        .createPool(
          value.tokenAddress,
          userAccount,
          NFT_FACTORY,
          parseInt(value.rewardAmount),
          parseInt(value.decimalValue),
          parseInt(value.rewardDuration) * 60,
          parseInt(value.totalTokenStake) * 10 ** 9
        )
        .send({ from: userAccount })
        .then((res) => {
          setTsxState(false);
          resetForm();
          setOpen(true);
        })
        .catch((err) => {
          setTsxState(false);
        });
    }
  };

  return (
    <Container maxWidth={false} className={classes.mainContainer}>
      {openWallets && <ConnectWallet handleClose={handleClose} />}
      {tsxState && <Loader />}
      <Typography className={classes.mainH1}>Create New Pool </Typography>
      <Box sx={{ flexGrow: 1 }}>
        <Grid container spacing={2} className={classes.gridRow}>
          <Grid item xs={10} sm={8} lg={6}>
            <Formik
              initialValues={{
                tokenAddress: "",
                ownerAddress: user,
                rewardAmount: "",
                decimalValue: "",
                rewardDuration: "",
                totalTokenStake: "",
              }}
              validationSchema={validations}
              onSubmit={(values, { resetForm }) => {
                createPool(values, resetForm);
              }}
            >
              {({
                errors,
                touched,
                handleChange,
                handleBlur,
                setFieldValue,
                values,
                handleSubmit,
              }) => (
                <>
                  <Card className={classes.poolCard}>
                    <Box className={classes.upperRow}>
                      <Typography className={classes.mainH1}>
                        Create Pool
                      </Typography>
                    </Box>
                    <Box className={classes.middleRow}>
                      <Typography className={classes.h2}>
                        Test token{" "}
                      </Typography>
                      <Box className={classes.inputWBtn}>
                        <input
                          type="string"
                          placeholder="Enter details"
                          className={classes.inputField}
                          value={values.tokenAddress}
                          onChange={handleChange("tokenAddress")}
                          onBlur={handleBlur("tokenAddress")}
                        />
                      </Box>
                      {touched.tokenAddress && errors.tokenAddress ? (
                        <Typography className={classes.errorMsg}>
                          {errors.tokenAddress}
                        </Typography>
                      ) : null}
                      <Typography className={classes.h2}>
                        Admin wallet address
                      </Typography>
                      <Box className={classes.inputWBtn}>
                        <input
                          type="string"
                          placeholder="Enter details"
                          className={classes.inputField}
                          value={account}
                          readOnly={true}
                        />
                      </Box>
                      <Grid container>
                        <Grid xs={12} md={6}>
                          <Typography className={classes.h2}>
                            Reward Percent{" "}
                          </Typography>
                          <Box className={classes.inputWBtn}>
                            <input
                              type="string"
                              placeholder="Enter reward"
                              className={classes.inputField}
                              value={values.rewardAmount}
                              onChange={handleChange("rewardAmount")}
                              onBlur={handleBlur("rewardAmount")}
                            />
                          </Box>
                          {touched.rewardAmount && errors.rewardAmount ? (
                            <Typography className={classes.errorMsg}>
                              {errors.rewardAmount}
                            </Typography>
                          ) : null}
                        </Grid>
                        <Grid xs={12} md={6}>
                          <Typography className={classes.h2}>
                            Decimal value
                          </Typography>
                          <Box className={classes.inputWBtn}>
                            <input
                              type="string"
                              placeholder="Enter decimal"
                              className={classes.inputField}
                              value={values.decimalValue}
                              onChange={handleChange("decimalValue")}
                              onBlur={handleBlur("decimalValue")}
                            />
                          </Box>
                          {touched.decimalValue && errors.decimalValue ? (
                            <Typography className={classes.errorMsg}>
                              {errors.decimalValue}
                            </Typography>
                          ) : null}
                        </Grid>
                      </Grid>

                      <Typography className={classes.h2}>
                        Rewards duration{" "}
                      </Typography>
                      <Box className={classes.inputWBtn}>
                        <input
                          type="string"
                          placeholder="Enter time duration for rewards"
                          className={classes.inputField}
                          value={values.rewardDuration}
                          onChange={handleChange("rewardDuration")}
                          onBlur={handleBlur("rewardDuration")}
                        />
                      </Box>
                      {touched.rewardDuration && errors.rewardDuration ? (
                        <Typography className={classes.errorMsg}>
                          {errors.rewardDuration}
                        </Typography>
                      ) : null}
                      <Typography className={classes.h2}>
                        Total Reward Token{" "}
                      </Typography>
                      <Box className={classes.inputWBtn}>
                        <input
                          type="string"
                          placeholder="Maximum amount of reward tokens to be staked"
                          className={classes.inputField}
                          value={values.totalTokenStake}
                          onChange={handleChange("totalTokenStake")}
                          onBlur={handleBlur("totalTokenStake")}
                        />
                      </Box>
                      {touched.totalTokenStake && errors.totalTokenStake ? (
                        <Typography className={classes.errorMsg}>
                          {errors.totalTokenStake}
                        </Typography>
                      ) : null}
                    </Box>
                    <Box className={classes.bottomRow}>
                      {account ? (
                        <Button
                          onClick={() => handleSubmit()}
                          variant="contained"
                          disabled={tsxState}
                          className={classes.mainBtn}
                        >
                          Create Pool
                        </Button>
                      ) : (
                        <Button
                          onClick={btnhandler}
                          variant="contained"
                          className={classes.connectBtn}
                        >
                          Connect Wallet
                        </Button>
                      )}
                    </Box>
                  </Card>
                </>
              )}
            </Formik>
          </Grid>
        </Grid>
      </Box>
      <Dialog
        open={open}
        onClose={handleClosePopUp}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        style={{ borderRadius: "10px" }}
      >
        <div style={{ margin: "20px" }}>
          <Typography className={classes.mainH1}>Pool Created </Typography>
          <Typography className={classes.h2}>
            Pool hase been created successfully. <br />
            checkout this pool on homepage
          </Typography>
          <div className="popupButton">
            <Button className={classes.mainBtn} onClick={() => navigate("/")}>
              Go to Home Page
            </Button>
          </div>
        </div>
      </Dialog>
    </Container>
  );
};

export default CreatePool;
