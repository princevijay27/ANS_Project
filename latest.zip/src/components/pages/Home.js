import {
  Card,
  Grid,
  Container,
  Typography,
  Box,
  Button,
  Modal,
  Fade,
  Backdrop,
} from "@mui/material";
import React, { useState, useEffect } from "react";
import { useStyles } from "./css/HomeCss";
import { useWeb3React } from "@web3-react/core";
import ConnectWallet from "./walletConnect/ConnectWallet";
import { OWNER_ADDRESS, NFT_FACTORY } from "./address";
import Web3 from "web3";
import ERC20 from "../../ABI/ERC20.json";
import fromExponential from "from-exponential";
import { Formik } from "formik";
import * as Yup from "yup";
import nftFactoryABI from "../../ABI/nftFactory.json";
import stakingABI from "../../ABI/StakingABI.json";
import {
  getNameSymbol,
  truncateAddress,
  allPools,
  getTime,
} from "./walletConnect/CommonFunction";
import { useNavigate } from "react-router-dom";
import { L1Block } from "./walletConnect/HttpProvider";
import Loader from "./walletConnect/Loader";
import RenderEmpty from "./walletConnect/Empty";
import { style } from "./UserRoute";
import { common } from "./css/CommonCss";

const Home = () => {
  const { classes } = useStyles();
  const { account, library, chainId = 1 } = useWeb3React();
  const lib = library;
  const navigate = useNavigate();
  const web3 = lib ? new Web3(lib?.provider) : L1Block();
  const [openWallets, setOpenWallets] = useState(false);
  const [tsxState, setTsxState] = useState(false);
  const [poolAddresses, setPoolAddress] = useState([]);
  const [allPoolsList, setAllPools] = useState([]);
  const [open, setOpen] = useState(false);
  const [open2, setOpen2] = useState(false);
  const [maxAmountStake, setMaxAmoutStake] = useState(0);

  const amountValidation = Yup.object({
    amount: Yup.number()
      .typeError("Amount should be a number.")
      .min(0)
      .moreThan(0, "You must enter valid amount.")
      .required("amount is required."),
  });

  const updateData = () => {
    setPoolAddress([]);
    getTotalPoolsCount();
  };

  useEffect(() => {
    if (poolAddresses.length) {
      let data = allPools(poolAddresses);
      setAllPools(data);
    }
  }, [poolAddresses]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setPoolAddress([]);
    updateData();
  }, [account, chainId]); // eslint-disable-line react-hooks/exhaustive-deps

  console.log(poolAddresses);

  const btnhandler = () => {
    setOpenWallets(true);
  };

  const handleClose = () => {
    setOpenWallets(false);
  };

  const getUserPoolEndTime = async (poolAddress) => {
    let amount;
    let userAccount = account;
    let instance = new web3.eth.Contract(stakingABI, poolAddress);
    await instance.methods
      .getPoolEndTime(account)
      .call({ from: userAccount })
      .then((res) => {
        amount = res;
        console.log(res, "getUserPoolEndTime");
      })
      .catch((err) => {
        console.log(err);
        amount = 0;
      });
    return amount;
  };

  const totalSupply = async (poolAddress) => {
    let address;
    let userAccount = account;
    let instance = new web3.eth.Contract(stakingABI, poolAddress);
    await instance.methods
      ._totalSupply()
      .call({ from: userAccount })
      .then((res) => {
        address = res;
      })
      .catch((err) => {
        address = 0;
      });
    return address;
  };

  const totalTokenStacked = async (poolAddress) => {
    let address;
    let userAccount = account;
    let instance = new web3.eth.Contract(stakingABI, poolAddress);
    await instance.methods
      .totalTokenStacked()
      .call({ from: userAccount })
      .then((res) => {
        address = res;
      })
      .catch((err) => {
        address = 0;
      });
    return address;
  };

  const getTotalPoolsCount = async () => {
    setTsxState(true);
    let instance = new web3.eth.Contract(nftFactoryABI, NFT_FACTORY);
    await instance.methods
      .poolId()
      .call()
      .then(async (res) => {
        for (let i = res; i >= 1; i--) {
          let address = await getPoolAddresses(i);
          try {
            let allowance_forPool;
            if (account) {
              allowance_forPool = await checkAllowance(address[0], address[1]);
            } else {
              allowance_forPool = 0;
            }
            let totalStake = await totalSupply(address[0]);
            let checkStaked = await getUserPoolEndTime(address[0]);
            let totalTokenStaked = await totalTokenStacked(address[0]);
            let poolTokenDetails = await getNameSymbol(web3, address[1]);
            let balance = await getBalance(address[1]);
            setPoolAddress((pre) => [
              ...pre,
              {
                id: i,
                totalStake: +totalStake / Math.pow(10, 9),
                rewardPercent: address[4],
                rewardTime: address[6],
                poolToken: address[1],
                poolAddress: address[0],
                allowance: allowance_forPool,
                allowance_forPool: allowance_forPool > 0 ? true : false,
                poolTokenDetails,
                balance,
                isSatked: checkStaked[4],
                totalTokenStaked,
              },
            ]);
          } catch (err) {
            setTsxState(false);
          }
        }
        setTsxState(false);
      })
      .catch(async (err) => {
        setTsxState(false);
      });
    setTsxState(false);
  };

  const getPoolAddresses = async (id) => {
    let address;
    let userAccount = account;
    let instance = new web3.eth.Contract(nftFactoryABI, NFT_FACTORY);
    await instance.methods
      .poolDetails(id)
      .call({ from: userAccount })
      .then((res) => {
        address = res;
        //
      })
      .catch((err) => {});
    return address;
  };

  const checkAllowance = async (address, tokenAddress) => {
    let instance = new web3.eth.Contract(ERC20, tokenAddress);
    let allowance = await instance.methods
      .allowance(account, address)
      .call({ from: account });
    return parseInt(allowance) / 10 ** 9;
  };

  const getBalance = async (token) => {
    if (account) {
      let instance = new web3.eth.Contract(ERC20, token);
      let balance = await instance.methods
        .balanceOf(account)
        .call({ from: account });
      return parseInt(balance) / 10 ** 9;
    } else {
      return 0;
    }
  };

  const approveAmount = (poolAddress, poolToken, setFieldValue) => {
    if (account) {
      setTsxState(true);
      let user = account;
      let amount = web3.utils.toBN(fromExponential(1000 * Math.pow(10, 9)));
      let instance = new web3.eth.Contract(ERC20, poolToken);
      instance.methods
        .approve(poolAddress, amount)
        .send({ from: user })
        .on("transactionHash", (res) => {})
        .on("receipt", (res) => {
          setFieldValue("amount", "", false);
          updateData();
        })
        .on("error", (res) => {
          setTsxState(false);
        });
    }
  };

  const callStaking = (amt, poolAddress, action) => {
    if (account) {
      setTsxState(true);
      let user = account;
      let amount = web3.utils.toBN(fromExponential(amt * Math.pow(10, 9)));
      let instance = new web3.eth.Contract(stakingABI, poolAddress);
      instance.methods
        .stake(amount)
        .send({ from: user })
        .on("transactionHash", (res) => {})
        .on("receipt", (res) => {
          action.resetForm();
          updateData();
        })
        .on("error", (res) => {
          setTsxState(false);
        });
    }
  };

  return (
    <Container maxWidth={false} className={classes.mainContainer}>
      {openWallets && <ConnectWallet handleClose={handleClose} />}
      {tsxState && <Loader />}
      {account === OWNER_ADDRESS ? (
        <Grid container>
          <Grid item xs={12} md={9}></Grid>
          {account ? (
            <Grid item xs={12} md={3} className={classes.flexRow}>
              <Grid item xs={5}>
                <Button
                  onClick={() => navigate("user")}
                  variant="contained"
                  className={classes.connectBtn}
                >
                  Your Pools
                </Button>
              </Grid>
              <Grid item xs={5}>
                <Button
                  onClick={() => navigate("createPool")}
                  variant="contained"
                  className={classes.connectBtn}
                >
                  Create Pool
                </Button>
              </Grid>
            </Grid>
          ) : null}
        </Grid>
      ) : (
        <Grid container>
          <Grid item xs={12} md={9}></Grid>
          {account ? (
            <Grid
              item
              xs={12}
              md={3}
              className={classes.flexRow}
              style={{ justifyContent: "flex-end" }}
            >
              <Grid item xs={5}>
                <Button
                  onClick={() => navigate("user")}
                  variant="contained"
                  className={classes.connectBtn}
                >
                  Your Pools
                </Button>
              </Grid>
            </Grid>
          ) : null}
        </Grid>
      )}
      <Box>
        <Grid container className={classes.cardRow} spacing={2}>
          {allPoolsList.length ? (
            allPoolsList.map((x) => (
              <Grid key={x.poolAddress} item xs={12} md={6} lg={4}>
                <Card className={classes.stakingCard}>
                  <Box className={classes.upperRow}>
                    <Typography className={classes.text}>STAKE</Typography>
                    <Box>
                      <Typography className={classes.text}>
                        Token Name: {x.poolTokenDetails?.name}
                      </Typography>
                      <Typography className={classes.text}>
                        Token Symbol: {x.poolTokenDetails?.symbol}
                      </Typography>
                    </Box>
                  </Box>
                  
                  <Box className={classes.middleRow}>
                    <Box className={classes.innerCards}>
                      <Typography className={classes.text}>
                        Start Staking
                      </Typography>
                      <Formik
                        initialValues={{
                          amount: "",
                        }}
                        validationSchema={amountValidation}
                        onSubmit={(values, action) => {
                          if (
                            parseInt(values.amount) + parseInt(x.totalStake) <=
                            +x.totalTokenStaked / 10 ** 9
                          ) {
                            callStaking(
                              parseInt(values.amount),
                              x.poolAddress,
                              action
                            );
                          } else if (
                            parseInt(x.totalTokenStaked / 10 ** 9) ===
                            parseInt(x.totalStake)
                          ) {
                            setOpen2(true);
                          } else {
                            let amount =
                              parseInt(x.totalTokenStaked / 10 ** 9) -
                              parseInt(x.totalStake);
                            setMaxAmoutStake(amount);
                            setOpen(true);
                          }
                        }}
                      >
                        {({
                          errors,
                          touched,
                          handleChange,
                          handleBlur,
                          setFieldValue,
                          values,
                          handleSubmit,
                        }) => (
                          <>
                            {account ? (
                              <Box>
                                <Box className={classes.inputWBtn}>
                                  <input
                                    type="string"
                                    placeholder="Enter Amount"
                                    value={values.amount}
                                    onChange={handleChange("amount")}
                                    onBlur={handleBlur("amount")}
                                    className={classes.inputField}
                                    disabled={x.isSatked}
                                  />
                                  <Button
                                    onClick={() =>
                                      setFieldValue("amount", x.balance)
                                    }
                                    disabled={x.isSatked}
                                    className={classes.maxBtn}
                                  >
                                    MAX
                                  </Button>
                                </Box>
                                {touched.amount && errors.amount ? (
                                  <Typography className={classes.errorMsg}>
                                    {errors.amount}
                                  </Typography>
                                ) : null}
                                <Typography className={classes.balance}>
                                  Leave balance : <b>{x.balance}</b>
                                </Typography>

                                {x.isSatked ? (
                                  <Box className={classes.flexRow}>
                                    <Button
                                      onClick={() => handleSubmit()}
                                      variant="contained"
                                      className={classes.connectBtnNew}
                                      disabled={tsxState || x.isSatked}
                                    >
                                      {x.isSatked ? "Already Staked" : "Stake"}
                                    </Button>
                                  </Box>
                                ) : x.allowance <= 0 ? (
                                  <>
                                    <Button
                                      onClick={() => {
                                        if (
                                          parseInt(
                                            x.totalTokenStaked / 10 ** 9
                                          ) === parseInt(x.totalStake)
                                        ) {
                                          setOpen2(true);
                                        } else {
                                          approveAmount(
                                            x.poolAddress,
                                            x.poolToken,
                                            setFieldValue
                                          );
                                        }
                                      }}
                                      variant="contained"
                                      className={classes.connectBtnNew}
                                      disabled={tsxState}
                                    >
                                      Approve
                                    </Button>
                                  </>
                                ) : (
                                  <Box className={classes.flexRow}>
                                    <Button
                                      onClick={() => handleSubmit()}
                                      variant="contained"
                                      className={classes.connectBtnNew}
                                      disabled={tsxState}
                                    >
                                      Stake
                                    </Button>
                                  </Box>
                                )}
                              </Box>
                            ) : (
                              <Button
                                onClick={btnhandler}
                                variant="contained"
                                className={classes.connectBtn}
                              >
                                Stake
                              </Button>
                            )}
                          </>
                        )}
                      </Formik>
                    </Box>

                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Total Token Staked:
                      </Typography>
                      <Typography className={classes.text}>
                        {x.totalStake} Token
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Total Tokens to be staked:
                      </Typography>
                      <Typography className={classes.text}>
                        {+x.totalTokenStaked / 10 ** 9} Token
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Reward Percent:
                      </Typography>
                      <Typography className={classes.text}>
                        {x.rewardPercent}%
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Total Duration:
                      </Typography>
                      <Typography className={classes.text}>
                        {getTime(+x.rewardTime / 60)}
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Pool Token:
                      </Typography>
                      <a
                        rel="noreferrer"
                        href={`https://testnet.bscscan.com/address/${x.poolToken}`}
                        target="_blank"
                        className={classes.linkText}
                      >
                        {truncateAddress(x.poolToken)}{" "}
                      </a>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                      Note: Please keep in mind! users allowed to stake one time from the same wallet: When pool ends you will not able to stake second time to the same pool: Please chose right amount of tokens to stake.
                      </Typography>
                    </Box>

                    <Box></Box>
                  </Box>
                  <Box className={classes.bottomRow}></Box>
                </Card>
              </Grid>
            ))
          ) : (
            <>{tsxState ? null : <RenderEmpty />}</>
          )}
        </Grid>
      </Box>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        onClose={() => setOpen(false)}
        open={open}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            <Typography
              style={styles.text}
              id="transition-modal-title"
              variant="h6"
              component="h3"
              backgroundColor="#FFEDFC"
              >
              Maximum Staked Reached!
            </Typography>
            <Typography backgroundColor="#FFEDFC" style={styles.para} id="transition-modal-description">
              
              You can not stake more then <b>{maxAmountStake}</b>
            </Typography>
            <Button style={styles.connectBtn} onClick={() => setOpen(false)}>
              Back
            </Button>
          </Box>
        </Fade>
      </Modal>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        onClose={() => setOpen2(false)}
        open={open2}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}
      >
        <Fade in={open2}>
          <Box sx={style}>
            <Typography
              style={styles.text}
              id="transition-modal-title"
              variant="h6"
              component="h2"
            >
              Pool is Locked!
            </Typography>
            <Typography backgroundColor="#FFEDFC" style={styles.para} id="transition-modal-description">
              This pool has been reached its maximum stake limit. Please stake
              on other pools
            </Typography>
            <Button style={styles.connectBtn} onClick={() => setOpen2(false)}>
              Back
            </Button>
          </Box>
        </Fade>
      </Modal>
    </Container>
  );
};

export default Home;

const styles = {
  connectBtn: {
    ...common.primarybtn,
    borderRadius: "8px",
  },
  text: {
    ...common.fonts,
    fontSize: "25px",
    padding: "2px",
    fontWeight: "600",
  },
  text2: {
    ...common.fonts,
    fontSize: "25px",
    padding: "2px 10px",
    fontWeight: "600",
  },
  para: {
    ...common.fonts,
    fontSize: "16px",
    padding: "20px 5px",
    fontWeight: "400",
  },
  para2: {
    ...common.fonts,
    fontSize: "16px",
    padding: "5px",
    fontWeight: "400",
  },
};
