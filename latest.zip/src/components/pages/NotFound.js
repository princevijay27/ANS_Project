import React from "react";
import { Container, Typography, Box } from "@mui/material";
import { useStyles } from "./css/HomeCss";

const NotFound = () => {
  const { classes } = useStyles();
  return (
    <Container maxWidth={false} className={classes.mainContainer}>
      <Box
        sx={{
          display: "flex",
          textAlign: "center",
          justifyContent: "center",
          height: "100%",
          width: "100%",
          flexDirection: "column",
          paddingTop: "10%",
        }}
      >
        <Typography className={classes.mainH1}>404 Page Not Found!</Typography>
        <Typography className={classes.textEmpty}>
          The URL or Path you entered is invalid or wrong!
        </Typography>
      </Box>
    </Container>
  );
};

export default NotFound;
