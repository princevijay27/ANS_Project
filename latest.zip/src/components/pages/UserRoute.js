import {
  Card,
  Grid,
  Container,
  Typography,
  Box,
  Button,
  Modal,
  Fade,
  Backdrop,
} from "@mui/material";
import React, { useState, useEffect } from "react";
import { useStyles } from "./css/HomeCss";
import { useWeb3React } from "@web3-react/core";
import ConnectWallet from "./walletConnect/ConnectWallet";
import { NFT_FACTORY } from "./address";
import Web3 from "web3";
import ERC20 from "../../ABI/ERC20.json";
import fromExponential from "from-exponential";
import { Formik } from "formik";
import * as Yup from "yup";
import nftFactoryABI from "../../ABI/nftFactory.json";
import stakingABI from "../../ABI/StakingABI.json";
import {
  truncateAddress,
  allPools,
  getNameSymbol,
  getTime,
} from "./walletConnect/CommonFunction";
import Loader from "./walletConnect/Loader";
import RenderEmpty from "./walletConnect/Empty";
import { common } from "./css/CommonCss";

export const style = {
  position: "absolute",
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  borderRadius: 5,
  backgroundColor: "#757578",
  p: 4,
};

const Home = () => {
  const { classes } = useStyles();
  const { account, library } = useWeb3React();
  const lib = library;
  const web3 = new Web3(lib?.provider);
  const [openWallets, setOpenWallets] = useState(false);
  const [tsxState, setTsxState] = useState(false);
  const [poolAddresses, setPoolAddress] = useState([]);
  const [allPoolsList, setAllPools] = useState([]);
  const [open, setOpen] = useState(false);
  const [rewards, setRewards] = useState({
    poolId: 0,
    reward: 0,
    poolAddress: "",
    amount: 0,
  });

  const [open2, setOpen2] = useState(false);
  const [poolEndingTime, setPoolEndingTime] = useState(0);

  const amountValidation = Yup.object({
    amount: Yup.number()
      .typeError("Amount should be a number.")
      .min(0)
      .moreThan(0, "You must enter valid amount.")
      .required("amount is required."),
  });

  useEffect(() => {
    setPoolAddress([]);
    if (account) {
      setOpenWallets(false);
      getTotalPoolsCount(account);
    }
  }, [account]); // eslint-disable-line react-hooks/exhaustive-deps

  const btnhandler = () => {
    setOpenWallets(true);
  };

  const handleClose = () => {
    setOpenWallets(false);
  };

  useEffect(() => {
    if (poolAddresses.length) {
      let data = allPools(poolAddresses);
      setAllPools(data);
    }
  }, [poolAddresses]); // eslint-disable-line react-hooks/exhaustive-deps

  console.log(allPoolsList);
  const getPoolDetails = async (acc, id) => {
    let userAccount = acc;
    let data;
    let instance = new web3.eth.Contract(nftFactoryABI, NFT_FACTORY);
    await instance.methods
      .poolDetails(id)
      .call({ from: userAccount })
      .then((res) => {
        data = res;
      })
      .catch((err) => {});
    return data;
  };

  const totalSupply = async (poolAddress) => {
    let address;
    let userAccount = account;
    let instance = new web3.eth.Contract(stakingABI, poolAddress);
    await instance.methods
      ._totalSupply()
      .call({ from: userAccount })
      .then((res) => {
        address = res;
      })
      .catch((err) => {});
    return address;
  };

  const totalEarned = async (poolAddress) => {
    let amount;
    let userAccount = account;
    let instance = new web3.eth.Contract(stakingABI, poolAddress);
    await instance.methods
      .earned(account)
      .call({ from: userAccount })
      .then((res) => {
        amount = res;
        console.log(res, "reward");
      })
      .catch((err) => {
        console.log(err);
        amount = 0;
      });
    return amount;
  };

  const getUserPoolEndTime = async (poolAddress) => {
    let data;
    let userAccount = account;
    let instance = new web3.eth.Contract(stakingABI, poolAddress);
    await instance.methods
      .getPoolEndTime(account)
      .call({ from: userAccount })
      .then((res) => {
        data = res;
        console.log(res, "getUserPoolEndTime");
      })
      .catch((err) => {
        console.log(err);
        data = [];
      });
    return data;
  };

  const totalStakedByUser = async (poolAddress) => {
    let amount;
    let userAccount = account;
    let instance = new web3.eth.Contract(stakingABI, poolAddress);
    await instance.methods
      .stakeBalanceOfUser(account)
      .call({ from: userAccount })
      .then((res) => {
        amount = res;
      })
      .catch((err) => {});
    return amount;
  };

  const getTotalPoolsCount = async (acc) => {
    setTsxState(true);
    let userAccount = acc;
    let instance = new web3.eth.Contract(nftFactoryABI, NFT_FACTORY);
    try {
      await instance.methods
        .userPool()
        .call({ from: userAccount })
        .then(async (res) => {
          try {
            const IDs = res;
            IDs.forEach(async (x) => {
              let poolDetail = await getPoolDetails(userAccount, x);
              let allowance = await checkAllowance(
                poolDetail[0],
                poolDetail[1]
              );
              let totalStake = await totalSupply(poolDetail[0]);
              let totalReward = await totalEarned(poolDetail[0]);
              let totalStakedUser = await totalStakedByUser(poolDetail[0]);
              let poolTokenDetails = await getNameSymbol(web3, poolDetail[1]);
              let balance = await getBalance(poolDetail[1]);
              let poolEndTime = 0;
              let newTime = await getUserPoolEndTime(poolDetail[0]);
              setPoolAddress((pre) => [
                ...pre,
                {
                  id: x,
                  allowance,
                  totalStake: +totalStake / Math.pow(10, 9),
                  rewardPercent: poolDetail[4],
                  rewardTime: poolDetail[6],
                  poolToken: poolDetail[1],
                  totalReward: +totalReward / Math.pow(10, 9),
                  totalStakedUser: +totalStakedUser / Math.pow(10, 9),
                  poolAddress: poolDetail[0],
                  poolTokenDetails,
                  balance,
                  poolEndTime,
                  newTime,
                },
              ]);
            });
            setTsxState(false);
          } catch (err) {}
        })
        .catch((err) => {
          setTsxState(false);
        });
    } catch (err) {}
  };

  const checkAllowance = async (address, poolToken) => {
    let instance = new web3.eth.Contract(ERC20, poolToken);
    let allowance = await instance.methods
      .allowance(account, address)
      .call({ from: account });
    return parseInt(allowance) / 10 ** 9;
  };

  const getBalance = async (token) => {
    if (account) {
      let instance = new web3.eth.Contract(ERC20, token);
      let balance = await instance.methods
        .balanceOf(account)
        .call({ from: account });
      return parseInt(balance) / 10 ** 9;
    } else {
      return 0;
    }
  };

  const callStaking = (amt, poolAddress, action) => {
    if (account) {
      setTsxState(true);
      let user = account;
      let amount = web3.utils.toBN(fromExponential(amt * Math.pow(10, 9)));
      let instance = new web3.eth.Contract(stakingABI, poolAddress);
      instance.methods
        .stake(amount)
        .send({ from: user })
        .on("transactionHash", (res) => {})
        .on("receipt", (res) => {
          setPoolAddress([]);
          action.resetForm();
          getTotalPoolsCount(account);
        })
        .on("error", (res) => {
          setTsxState(false);
        });
    }
  };

  const claimReward = (poolId) => {
    setOpen(false);
    if (account) {
      setTsxState(true);
      let user = account;
      let instance = new web3.eth.Contract(nftFactoryABI, NFT_FACTORY);
      instance.methods
        .withdrawRewardToken(+poolId)
        .send({ from: user })
        .on("transactionHash", (res) => {})
        .on("receipt", (res) => {
          setPoolAddress([]);
          getTotalPoolsCount(account);
        })
        .on("error", (res) => {
          setTsxState(false);
        });
    }
  };

  const unstakeFromPool = () => {
    setOpen(false);
    if (account) {
      setTsxState(true);
      let user = account;
      let instance = new web3.eth.Contract(nftFactoryABI, NFT_FACTORY);
      instance.methods
        .withdrawRewardToken(rewards.poolId)
        .send({ from: user })
        .on("transactionHash", (res) => {})
        .on("receipt", (res) => {
          setTsxState(false);
          setPoolAddress([]);
          getTotalPoolsCount(account);
        })
        .on("error", (res) => {
          setTsxState(false);
        });
    }
  };

  const unstakeFromPoolNEW = (address) => {
    if (account) {
      setTsxState(true);
      let user = account;
      let instance = new web3.eth.Contract(stakingABI, address);
      instance.methods
        .withdraw()
        .send({ from: user })
        .on("transactionHash", (res) => {
          console.log("unstake hash", res);
        })
        .on("receipt", (res) => {
          console.log(res, "unstake done");
          setPoolAddress([]);
          getTotalPoolsCount(account);
        })
        .on("error", (res) => {
          setTsxState(false);
        });
    }
  };

  const getPoolEndedTime = (timeStamp) => {
    let currentTime = new Date().getTime().toString();
    let poolTime = +timeStamp * 1000;
    let time = Math.ceil((poolTime - currentTime) / 60000);
    if (time > 0) {
      return time;
    } else {
      return 0;
    }
  };

  return (
    <Container maxWidth={false} className={classes.mainContainer}>
      {openWallets && <ConnectWallet handleClose={handleClose} />}
      {tsxState && <Loader />}
      <Box>
        <Typography className={classes.mainH1}>Your Total Pools </Typography>
        <Grid container className={classes.cardRow} spacing={2}>
          {allPoolsList.length > 0 ? (
            allPoolsList.map((x) => (
              <Grid key={x.id} item xs={12} md={6} lg={4}>
                <Card className={classes.stakingCard}>
                  <Box className={classes.upperRow}>
                    <Typography className={classes.text}>STAKE</Typography>
                    <Box>
                      <Typography className={classes.text}>
                        Token Name: {x.poolTokenDetails?.name}
                      </Typography>
                      <Typography className={classes.text}>
                        Token Symbol: {x.poolTokenDetails?.symbol}
                      </Typography>
                    </Box>{" "}
                  </Box>
                  <Box className={classes.middleRow}>
                    <Box className={classes.innerCards}>
                      <Formik
                        initialValues={{
                          amount: "",
                        }}
                        validationSchema={amountValidation}
                        onSubmit={(values, action) => {
                          callStaking(
                            parseInt(values.amount),
                            x.poolAddress,
                            action
                          );
                        }}
                      >
                        {({
                          errors,
                          touched,
                          handleChange,
                          handleBlur,
                          setFieldValue,
                          values,
                          handleSubmit,
                        }) => (
                          <>
                            {account ? (
                              new Date().getTime().toString() >=
                              x.newTime[3] ? (
                                <>
                                  <Typography style={styles.text2}>
                                    Pool Ended
                                  </Typography>
                                  <Grid container className={classes.flexRow}>
                                    <Grid item xs={12} md={5}>
                                      <Button
                                        onClick={() => claimReward(x.id)}
                                        variant="contained"
                                        className={classes.connectBtnNew}
                                        disabled={tsxState}
                                      >
                                        Claim
                                      </Button>
                                    </Grid>
                                    <Grid item xs={12} md={5}>
                                      <Button
                                        onClick={() => {
                                          let time = getPoolEndedTime(
                                            x.newTime[3]
                                          );
                                          console.log("callded");
                                          setRewards({
                                            amount: values.amount
                                              ? values.amount
                                              : x.totalStakedUser,
                                            poolAddress: x.poolAddress,
                                            reward: x.totalReward,
                                            poolId: x.id,
                                          });
                                          if (time > 0) {
                                            setPoolEndingTime(time);
                                            setOpen2(true);
                                          } else if (
                                            parseInt(x.totalReward) > 0
                                          ) {
                                            setOpen(true);
                                          } else {
                                            unstakeFromPoolNEW(x.poolAddress);
                                          }
                                        }}
                                        variant="contained"
                                        className={classes.connectBtnNew}
                                        disabled={tsxState}
                                      >
                                        Unstake
                                      </Button>
                                    </Grid>
                                  </Grid>
                                </>
                              ) : (
                                <Box>
                                  <Typography className={classes.text}>
                                    Start Staking
                                  </Typography>
                                  <Box className={classes.inputWBtn}>
                                    <input
                                      type="string"
                                      placeholder="Enter Amount"
                                      value={values.amount}
                                      onChange={handleChange("amount")}
                                      onBlur={handleBlur("amount")}
                                      className={classes.inputField}
                                    />
                                    <Button
                                      onClick={() =>
                                        setFieldValue("amount", x.balance)
                                      }
                                      className={classes.maxBtn}
                                    >
                                      MAX
                                    </Button>
                                  </Box>
                                  {touched.amount && errors.amount ? (
                                    <Typography className={classes.errorMsg}>
                                      {errors.amount}
                                    </Typography>
                                  ) : null}
                                  <Typography className={classes.balance}>
                                    Leave balance : <b>{x.balance}</b>
                                  </Typography>
                                  <>
                                    <Grid container className={classes.flexRow}>
                                      <Grid item xs={12} md={5}>
                                        <Button
                                          onClick={() => claimReward(x.id)}
                                          variant="contained"
                                          className={classes.connectBtnNew}
                                          disabled={tsxState}
                                        >
                                          Claim
                                        </Button>
                                      </Grid>
                                      <Grid item xs={12} md={5}>
                                        <Button
                                          onClick={() => {
                                            let time = getPoolEndedTime(
                                              x.newTime[3]
                                            );
                                            console.log("callded");
                                            setRewards({
                                              amount: values.amount
                                                ? values.amount
                                                : x.totalStakedUser,
                                              poolAddress: x.poolAddress,
                                              reward: x.totalReward,
                                              poolId: x.id,
                                            });
                                            if (time > 0) {
                                              setPoolEndingTime(time);
                                              setOpen2(true);
                                            } else if (
                                              parseInt(x.totalReward) > 0
                                            ) {
                                              setOpen(true);
                                            } else {
                                              unstakeFromPoolNEW(x.poolAddress);
                                            }
                                          }}
                                          variant="contained"
                                          className={classes.connectBtnNew}
                                          disabled={tsxState}
                                        >
                                          Unstake
                                        </Button>
                                      </Grid>
                                    </Grid>
                                  </>
                                </Box>
                              )
                            ) : (
                              <Button
                                onClick={btnhandler}
                                variant="contained"
                                className={classes.connectBtn}
                              >
                                Connect Wallet
                              </Button>
                            )}
                          </>
                        )}
                      </Formik>
                    </Box>

                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Reward earned:
                      </Typography>
                      <Typography className={classes.text}>
                        {x.totalReward} Token
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Your staked amount :
                      </Typography>
                      <Typography className={classes.text}>
                        {x.totalStakedUser} Token
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Total token staked:
                      </Typography>
                      <Typography className={classes.text}>
                        {x.totalStake} Token
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Reward Percent:
                      </Typography>
                      <Typography className={classes.text}>
                        {x.rewardPercent}%
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Total Duration:
                      </Typography>
                      <Typography className={classes.text}>
                        {getTime(+x.rewardTime / 60)}
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Pool Ending in:
                      </Typography>
                      <Typography className={classes.text}>
                        {getPoolEndedTime(x.newTime[3])}
                      </Typography>
                    </Box>
                    <Box className={classes.flexRow}>
                      <Typography className={classes.text}>
                        Pool Token:
                      </Typography>
                      <a
                        rel="noreferrer"
                        href={`https://testnet.bscscan.com/address/${x.poolToken}`}
                        target="_blank"
                        className={classes.linkText}
                      >
                        {truncateAddress(x.poolToken)}{" "}
                      </a>
                    </Box>

                    <Box></Box>
                  </Box>
                  <Box className={classes.bottomRow}></Box>
                </Card>
              </Grid>
            ))
          ) : (
            <>{tsxState ? null : <RenderEmpty />}</>
          )}
        </Grid>
      </Box>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        onClose={() => setOpen(false)}
        open={open}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            <Typography
              style={styles.text}
              id="transition-modal-title"
              variant="h6"
              component="h2"
              backgroundColor="#FFEDFC"
            >
              Unstake
            </Typography>
            <Typography backgroundColor="#FFEDFC" style={styles.para} id="transition-modal-description">
              Before unstaking you will get your reward after that you will be
              unstaked from this pool. It will take little more time than usual
              transaction
            </Typography>
            <Typography style={styles.para2} id="transition-modal-description">
              Reward Amount:- <b>{rewards.reward}</b>
            </Typography>
            <Button style={styles.connectBtn} onClick={() => unstakeFromPool()}>
              Unstake
            </Button>
          </Box>
        </Fade>
      </Modal>

      {/* pool not ended modal */}
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        onClose={() => setOpen2(false)}
        open={open2}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}
      >
        <Fade in={open2}>
          <Box sx={style}>
            <Typography
              style={styles.text}
              id="transition-modal-title"
              variant="h6"
              component="h2"
            >
              Pool Not Ended!
            </Typography>
            <Typography backgroundColor="#FFEDFC" style={styles.para} id="transition-modal-description">
              You can not Unstake before pool ends.
            </Typography>
            <Typography backgroundColor="#FFEDFC" style={styles.para2} id="transition-modal-description">
              Pool Ending in {poolEndingTime} Minutes
            </Typography>
            <Button style={styles.connectBtn} onClick={() => setOpen2(false)}>
              Back
            </Button>
          </Box>
        </Fade>
      </Modal>
    </Container>
  );
};

export default Home;

const styles = {
  connectBtn: {
    ...common.primarybtn,
    borderRadius: "8px",
  },
  text: {
    ...common.fonts,
    fontSize: "25px",
    padding: "2px",
    fontWeight: "600",
  },
  text2: {
    ...common.fonts,
    fontSize: "25px",
    padding: "2px 10px",
    fontWeight: "600",
  },
  para: {
    ...common.fonts,
    fontSize: "16px",
    padding: "20px 5px",
    fontWeight: "400",
  },
  para2: {
    ...common.fonts,
    fontSize: "16px",
    padding: "5px",
    fontWeight: "400",
  },
};
