// text start color - #ed2c78 , #fb9c83
// border = #a5b2c3
// button = #f0346e , #fc6650
export const common = {
  row: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
  },
  primarybtn: {
    position: "relative",
    backgroundColor: "#FE20E0", // E53E3E
    backgroundImage: "linear-gradient(to right, #FE20E0 , #fc6650)",
    borderRadius: "24px",
    color: "#FFFFFF",
    fontSize: "16px",
    textTransform: "none",
    fontWeight: "600",
  },
  fonts: {
    color: "#000",
  },
  mainContainer: {
    // backgroundColor: "#f7f7ff",
    minHeight: "100vh",
    width: "100%",
    marginTop: "100px",
  },
  cards: {
    margin: "50px 0",
    borderRadius: "20px",
  },
  inputField: {
    color: "#000",
    fontWeight: "600",
    width: "100%",
    padding: "10px 10px",
    fontSize: "15px",
    backgroundColor: "#FFFFFF",
    border: "none",
    borderRadius: "6px",
    outline: "none",
  },
  upperCardRow: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#FCBFBF",
    padding: "20px",
    borderBottom: "1px solid #4f4c5e",
  },
  cardMiddleRow: {
    backgroundColor: "#FFE0E5",
    padding: "20px",
    borderBottom: "1px solid #4f4c5e",
  },
  cardBottomRow: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#FF94EF",
    padding: "20px",
  },
  inputWBtn: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#FFF0FD",
    borderRadius: "6px",
    padding: "2px",
    margin: "2px",
  },
  gridRow: {
    display: "flex",
    justifyContent: "center",
  },
  buttons: {
    backgroundColor: "#F33CFE",
    backgroundImage: "linear-gradient(to right, #BF55FF , #fc6650)",
    color: "#FFFFFF",
    fontSize: "16px",
    textTransform: "none",
    width: "100%",
    fontWeight: "600",
    borderRadius: "6px",
    margin: "10px 0",
    "&:hover": {
      backgroundColor: "#f0346e",
    },
  },
  errorMsg: {
    color: "#ED64A6",
    fontWeight: "400",
    padding: "5px",
  },
};
