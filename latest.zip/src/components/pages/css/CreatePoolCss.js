import { makeStyles } from "tss-react/mui";
import { common } from "./CommonCss";

export const useStyles = makeStyles()((theme) => {
  return {
    mainHeader: {
      ...common.mainContainer,
    },
    mainH1: {
      fontSize: "25px",
      fontWeight: "bold",
      color: "#000",
    },
    h2: {
      fontSize: "16px",
      fontWeight: "400",
      color: "#000",
      padding: "1px 10px",
    },
    connectBtn: {
      ...common.buttons,
    },
    poolCard: {
      ...common.cards,
      margin: "45px 0",
    },
    inputField: {
      ...common.inputField,
    },
    upperRow: {
      ...common.upperCardRow,
    },
    middleRow: {
      ...common.cardMiddleRow,
    },
    bottomRow: {
      ...common.cardBottomRow,
    },
    inputWBtn: {
      ...common.inputWBtn,
    },
    gridRow: {
      ...common.gridRow,
    },
    mainBtn: {
      ...common.buttons,
    },
    errorMsg: {
      ...common.errorMsg,
      padding: "0 10px",
    },
  };
});
