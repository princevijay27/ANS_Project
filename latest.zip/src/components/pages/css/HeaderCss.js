import { makeStyles } from "tss-react/mui";
import { common } from "./CommonCss";

export const useStyles = makeStyles()((theme) => {
  return {
    mainGrid: {
      ...common.row,
      width: "100%",
      height: "100%",
      // backgroundColor: "#FD6D4B", // #f0346d
      backgroundColor: "red" /* For browsers that do not support gradients */,
      backgroundImage: "linear-gradient(to right, #f0346d , #FD6D4B)",
      padding: "20px 0",
    },
    connectBtn: {
      ...common.primarybtn,
    },
    text: {
      ...common.fonts,
      padding: "15px",
    },
  };
});
