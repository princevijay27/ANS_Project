import { makeStyles } from "tss-react/mui";
import { common } from "./CommonCss";

export const useStyles = makeStyles()((theme) => {
  return {
    text: {
      ...common.fonts,
    },
    textEmpty: {
      ...common.fonts,
      color: "#FFFFF",
    },
    mainH1: {
      ...common.fonts,
      fontSize: "22px",
      padding: "20px",
      fontWeight: "600",
    },
    mainH2: {
      ...common.fonts,
      color: "#6E6E6E",
      fontSize: "22px",
      padding: "20px",
      fontWeight: "600",
      position: "absolute",
      [theme.breakpoints.between("xs", "sm")]: {
        top: "35%",
        left: "20%",
      },
      top: "35%",
      left: "40%",
    },
    inputWBtn: {
      ...common.inputWBtn,
    },
    errorMsg: {
      ...common.errorMsg,
    },
    balance: {
      color: "#000",
      margin: "5px",
    },
    maxBtn: {
      color: "#f0346e",
      fontWeight: "600",
      borderRadius: "12px",
    },
    linkText: {
      color: "#ED64A6",
      fontWeight: "bold",
      cursor: "pointer",
      textDecoration: "none",
      "&:hover": {
        color: "#FFFF33",
      },
    },
    inputField: {
      ...common.inputField,
    },
    mainContainer: {
      ...common.mainContainer,
      // height: '100vh',
      position: "relative",
      zIndex: "1",
    },
    flexRow: {
      ...common.row,
      padding: "2px 0",
    },
    flexEnd: {
      textAlign: "start",
    },
    bottomBtn: {
      border: "1px solid #60bea6",
      borderRadius: "24px",
      backgroundColor: "#19010d",
    },
    connectBtn: {
      ...common.buttons,
    },
    connectBtnNew: {
      ...common.primarybtn,
      width: "100%",
      borderRadius: "12px",
      margin: "10px 2px",
      "&:disabled": {
        backgroundColor: "grey",
      },
    },
    innerCards: {
      border: "1px solid #2e2d34",
      borderRadius: "15px",
      padding: "15px 10px",
      margin: "10px 0",
    },
    cardRow: {
      ...common.gridRow,
    },
    stakingCard: {
      margin: "50px 0",
      borderRadius: "20px",
      boxShadow: "2px 2px 2px 2px grey",
    },
    upperRow: {
      ...common.upperCardRow,
      padding: "30px 20px",
    },
    middleRow: {
      ...common.cardMiddleRow,
      padding: "10px",
    },
    bottomRow: {
      backgroundColor: "#FF9191",
      padding: "30px 20px",
      borderBottom: "1px solid #4f4c5e",
    },
  };
});
