import { makeStyles } from "tss-react/mui";
import { common } from "./CommonCss";

export const useStyles = makeStyles()((theme) => {
  return {
    mainHeader: {
      ...common.mainContainer,
      minHeight: "100vh",
    },
    h1: {
      color: "#FFFFFF",
      fontSize: "24px",
      fontWeight: "bold",
      padding: "20px",
    },
  };
});
