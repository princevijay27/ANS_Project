import * as React from "react";
import OutlinedInput from "@mui/material/OutlinedInput";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { useWeb3React } from "@web3-react/core";
import { truncateAddress } from "./CommonFunction";
import { Typography } from "@mui/material";
import jazzicon from "@metamask/jazzicon";

const ITEM_HEIGHT = 40;
const ITEM_PADDING_TOP = 0;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

export default function MultipleSelectPlaceholder() {
  const [personName, setPersonName] = React.useState([]);

  const { account, deactivate } = useWeb3React();

  const avatarRef = React.useRef();
  React.useEffect(() => {
    const element = avatarRef.current;
    if (element && account) {
      const addr = account.slice(2, 10);
      const seed = parseInt(addr, 16);
      const icon = jazzicon(20, seed); //generates a size 20 icon
      if (element.firstChild) {
        element.removeChild(element.firstChild);
      }
      element.appendChild(icon);
    }
  }, [account, avatarRef]);

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  return (
    <div>
      <FormControl>
        <Select
          multiple
          displayEmpty
          value={personName}
          onChange={handleChange}
          input={<OutlinedInput />}
          style={styles.mainHeader}
          renderValue={(selected) => {
            if (selected.length === 0) {
              return (
                <Typography style={styles.address}>
                  {truncateAddress(account)}
                </Typography>
              );
            }

            return selected.join(", ");
          }}
          MenuProps={MenuProps}
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem
            onClick={() => {
              deactivate();
              localStorage.setItem("isWalletConnected", false);
            }}
          >
            Disconnect
          </MenuItem>
        </Select>
      </FormControl>
    </div>
  );
}

const styles = {
  mainHeader: {
    backgroundColor: "#f7f7ff",
    borderRadius: "50px",
    width: "10rem",
    height: "2rem",
  },
  address: {
    color: "#000",
    padding: "0 5px",
    fontSize: "16px",
    fontWeight: "400",
  },
  walletIcon: {},
};
