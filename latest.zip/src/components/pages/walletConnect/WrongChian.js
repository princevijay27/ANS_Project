import * as React from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { useWeb3React } from "@web3-react/core";
import { common } from "../css/CommonCss";
import { isMobile } from "react-device-detect";


const style = {
  position: "absolute",
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: isMobile ? "66%" : 450,
  borderRadius: 5,
  backgroundColor: "#757578",
  p: 4,
};

export default function TransitionsModal() {
  const { account, chainId, library } = useWeb3React();
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    if (account) {
      if (chainId !== 56) {
        setOpen(true);
      } else {
        setOpen(false);
      }
    } else {
      setOpen(false);
    }
  }, [account, chainId]);

  const switchNetwork = async () => {
    console.debug(`Switching to chain 56`, 56);
    const params = 56;
    try {
      await library?.send("wallet_switchEthereumChain", [
        { chainId: `0x${params.toString(16)}` },
        account,
      ]);
    } catch (switchError) {
      if (switchError.code === 4902) {
        try {
          await library?.send("wallet_addEthereumChain", [params, account]);
        } catch (addError) {
          console.error(`Add chain error ${addError}`);
        }
      }
      console.error(`Switch chain error ${switchError}`);
    }
  };

  return (
    <div>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            <Typography
              style={styles.text}
              id="transition-modal-title"
              variant="h6"
              component="h2"
              backgroundColor="#FFEDFC"
            >
              Worng Chain!
            </Typography>
            <Typography backgroundColor="#FFEDFC" style={styles.para} id="transition-modal-description">
              Swicth to BNB Smart Chain Testnet for access the features.
            </Typography>
            <Button style={styles.connectBtn} onClick={() => switchNetwork()}>
              Switch to BNB Smart Chain Testnet
            </Button>
          </Box>
        </Fade>
      </Modal>
    </div>
  );
}

const styles = {
  connectBtn: {
    ...common.primarybtn,
    borderRadius: "8px",
  },
  text: {
    ...common.fonts,
    fontSize: "25px",
    padding: "2px",
    fontWeight: "600",
  },
  para: {
    ...common.fonts,
    fontSize: "16px",
    padding: "20px 5px",
    fontWeight: "400",
  },
};
